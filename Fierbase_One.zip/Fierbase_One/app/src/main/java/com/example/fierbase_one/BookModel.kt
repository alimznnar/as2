package com.example.fierbase_one

class BookModel(var bookname:String,var nameauthor:String
,var bookyear:String,var bookprice:String,var img:Int) {

}